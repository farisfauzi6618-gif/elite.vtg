# Audit keamanan ELITE.VTG — 8 Oktober 2026

## Kesimpulan
Pada jalur yang diperiksa, pengunjung luar tidak dapat mengubah produk/stok/QRIS, membaca bukti pembayaran orang lain, atau mengesahkan pembayaran tanpa izin pemilik. Ini adalah hasil pemeriksaan kode, pengujian terisolasi, dan pemeriksaan terbatas pada website produksi; bukan jaminan bebas seluruh kerentanan.

## Bukti dan batas pemeriksaan
- GET /api/admin pada katalog dan order produksi: anonim ditolak 401; percobaan menyisipkan header identitas pemilik dengan ID palsu juga ditolak 401. Isi data admin tidak diambil atau disimpan.
- 116 pengujian order, pembayaran, pengiriman, dan integrasi katalog; 38 pengujian Worker katalog dengan D1/R2 terisolasi; 13 kasus domain: semuanya lulus. TypeScript, build kedua aplikasi, dan pemeriksaan diff lulus.
- Pengujian transaksi memakai database sementara dan layanan Telegram/pengiriman simulasi. Tidak ada pembayaran nyata, order palsu produksi, booking, atau pesan Telegram pengujian ke pemilik.
- Tidak dilakukan serangan beban produksi, pengujian pengambilalihan akun, atau pemindaian menyeluruh infrastruktur/dependensi. Proteksi platform autentikasi dipercaya pada batas hosting dan juga diperiksa melalui akses anonim/header palsu di atas.

## Temuan yang diperbaiki
| Temuan | Perbaikan |
| --- | --- |
| Body order dapat melewati batas saat Content-Length hilang/palsu; multipart dibaca sebelum batas total nyata | Pembaca stream menghitung byte nyata, berhenti di batas, dan membatasi JSON, unggahan, serta webhook. Content-Type JSON/multipart diperiksa. |
| Admin katalog menerima mutasi tanpa Origin | Origin wajib sama dengan aplikasi untuk mutasi admin; origin lintas situs dan Origin kosong ditolak. |
| Checkout katalog publik tidak memiliki batas frekuensi | Maksimal 60 percobaan per IP per jam; penghitung tersimpan D1, identitas IP di-hash, penghitung kedaluwarsa dibersihkan. Batas membantu menahan penyalahgunaan, bukan perlindungan lengkap serangan terdistribusi. |
| Pembatas order dijalankan setelah request katalog | Pembatas 12 percobaan per IP/jam dipindahkan sebelum parsing/akses katalog. |
| Halaman admin tidak memblokir iframe | CSP frame-ancestors none dan X-Frame-Options DENY pada halaman admin; cache private/no-store. |
| URL checkout/pelacakan dapat dibawa melalui Referer | Referrer-Policy no-referrer ditambahkan pada respons kedua aplikasi. |
| Harga pesanan manual berasal dari pembeli | Pesan Telegram untuk pesanan manual kini secara eksplisit meminta pencocokan harga sebelum konfirmasi; alur manual lama dipertahankan. |

## Kontrol pembayaran yang diuji
- Nama dan harga checkout katalog dibaca dari pilihan yang tersimpan di server. Nilai harga/total/ongkir/status lunas dari browser tidak dipercaya; ongkir dibaca dari quote server yang masih berlaku.
- Endpoint QRIS, bot, pengiriman, stok, dan bukti admin memeriksa akun pemilik di backend. Cookie order acak, HttpOnly, Secure pada HTTPS, SameSite Strict; hanya hash sesi disimpan.
- Invoice dan bukti tidak bisa dibaca hanya dengan nomor invoice atau cookie acak. Produk/foto draf tidak tersedia publik.
- Webhook Telegram memeriksa secret server; konfirmasi memeriksa akun pemilik, chat pribadi pemilik, dan message ID invoice yang tersimpan. Header/akun/message ID palsu ditolak.
- Upload gambar hanya mengubah status menjadi proof_received. Tidak mengubah menjadi payment_confirmed, memotong stok, atau membuat pengiriman.
- Penghubung stok membutuhkan secret server. Pemotongan atomik dan idempoten, menolak stok negatif/konflik serta transaksi ulang. Pengiriman ditahan jika sinkronisasi stok gagal.
- Token bot/API dikonfigurasi di server, kredensial tersimpan terenkripsi. Respons publik tidak memuat token, konfigurasi privat, atau lokasi bukti pembayaran.

## Hal yang tetap perlu dilakukan pemilik
1. Sebelum menekan konfirmasi Telegram, cocokkan invoice dan nominal dengan dana yang benar-benar masuk di aplikasi pembayaran. Screenshot bisa dipalsukan; sistem QRIS saat ini tidak memiliki verifikasi settlement otomatis dari penyedia pembayaran.
2. Checkout dari katalog mengunci harga. Form order manual tetap membolehkan pembeli mengisi nominal sesuai kesepakatan, sehingga wajib dicocokkan; order manual tidak memotong stok katalog otomatis.
3. Jaga akun admin ChatGPT, Telegram, dan token bot; aktifkan autentikasi dua langkah pada akun yang digunakan. Akun pemilik yang diambil alih mempunyai izin pemilik.
4. Stok belum direservasi ketika checkout. Dua pembeli unit terakhir bisa membayar sebelum konfirmasi; hanya satu pemotongan dapat berhasil dan pesanan lain ditahan sebagai konflik.

## Referensi teknis resmi
- OWASP REST Security Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/REST_Security_Cheat_Sheet.html
- OWASP Clickjacking Defense: https://cheatsheetseries.owasp.org/cheatsheets/Clickjacking_Defense_Cheat_Sheet.html
- Telegram Bot API, setWebhook secret_token: https://core.telegram.org/bots/api#setwebhook


## Perubahan kebijakan: akses tim dengan tautan — 8 Oktober 2026
Atas permintaan pemilik, admin katalog kini juga menerima tiga kredensial tautan tim. Ini adalah akses yang sengaja didelegasikan; perlindungan satu akun pemilik tetap digunakan untuk pengelolaan tautan, koneksi, dan aplikasi pembayaran.

Tautan memakai token acak 256 bit dalam URL fragment, tidak dalam query atau path request. Login menukar token menjadi cookie sesi HttpOnly, Secure pada HTTPS, SameSite Strict. Database menyimpan hash token dan hash sesi; token yang diperlukan pemilik untuk menyalin ulang disimpan terenkripsi AES-GCM dengan rahasia server terpisah. Token/link tidak dikirim ke pembeli, tidak masuk riwayat stok, dan tidak dipakai di aplikasi pembayaran.

Server memeriksa grant aktif, expiry, versi grant, dan sesi pada setiap akses admin tim. Pencabutan atau rotasi token membatalkan semua sesi grant yang sama. Login dibatasi 30 percobaan per IP per jam dan memerlukan Origin aplikasi. Tautan berlaku 90 hari, sesi paling lama 30 hari. Tiga grant bukan batas tiga perangkat; anggota dapat memakai HP/laptop. Siapa pun yang menerima salinan tautan dapat memakai grant tersebut. Label nama anggota merupakan atribusi per kredensial, bukan identitas individu yang terverifikasi.

Verifikasi perubahan ini: 48 kasus Worker/D1/R2 katalog serta 22 kasus integrasi order (21 alur sebelumnya dan satu kasus khusus tim versus pembayaran) lulus. Kasus khusus menguji cookie tim tidak dapat mengganti QRIS, membaca bukti order, atau mengesahkan pembayaran Telegram. Pengujian tidak membuat transaksi atau pesan produksi.
