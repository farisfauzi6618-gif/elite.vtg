# ELITE.VTG — Shop: panduan dan status

Toko web ELITE.VTG memakai aplikasi katalog yang sama dan terhubung ke form pesanan/pembayaran yang sudah ada. Instagram menjadi saluran promosi. Semua barang dimasukkan secara manual; foto dan tombol barang membuka halaman detail toko, tanpa tautan postingan Instagram.

## Penggunaan admin

1. Buka `/admin` dan masuk dengan akun ChatGPT pemilik yang diizinkan di konfigurasi server `ADMIN_EMAIL`.
2. Pilih **Tambah barang → Isi formulir barang**. Formulir dimulai kosong dengan satu kelompok ukuran; harga, fit, kondisi, minus, dan stok tidak diisi otomatis. Unggah sampai 12 foto JPG/PNG/WebP (maksimal 8 MB per foto) di formulir.
3. Periksa nama, brand, **satu kategori utama**, **Ciri tambahan**, warna, harga, kondisi, minus, size tag, **Size fit to** menurut penilaian Anda, **Details size — Panjang/Lebar (cm)** hasil pengukuran manual, dan **stok fisik saat ini**. Isi deskripsi untuk pembeli bila perlu. Pilih foto utama; tambah atau hapus foto detail/minus di galeri, lalu simpan.
4. Untuk barang satu pcs, isi **Jumlah stok (pcs)** dengan 1. Pembeli melihat stok, **Size fit to**, dan **Details size** berdampingan, tanpa label “Kelompok 1”. Fit S–M merupakan satu kelompok: pilih S dan M untuk filter, dengan satu jumlah stok bersama. Klik **Tambah size lain** jika tersedia varian lain; setiap varian memiliki tab dengan fit, panjang/lebar, dan jumlah stok sendiri. Barang satu ukuran langsung menampilkan formulir tanpa tab. Jangan membuat dua varian dengan stok yang sama. Size tag dapat dicatat admin, tetapi tidak ditampilkan ke pembeli.
5. Informasi tidak jelas dibiarkan kosong dan ditandai. Harga admin Shopee tidak ditambahkan. Jika kelompok hasil baca tidak dipakai, set stok 0.
6. Centang konfirmasi pemeriksaan lalu **Terbitkan ke katalog**. **Simpan sebagai draf** menyembunyikan barang dari pembeli.
7. Di tab **Stok**, − mengurangi satu unit, + menambah satu. Untuk koreksi angka langsung, buka editor kelompok.
8. Buka **Riwayat & pembatalan** untuk membatalkan perubahan stok terakhir yang belum digantikan perubahan lain. Semua perubahan dan undo tercatat.

Stok nol tidak muncul di katalog/filter. Ketika seluruh kelompok habis, data dan riwayat tetap berada di admin. Stok berkurang otomatis setelah pemilik mengonfirmasi pembayaran Telegram untuk pesanan yang membawa pilihan barang toko. Pesanan manual dan penjualan melalui kanal lain memerlukan koreksi stok admin.

## Pengalaman pembeli

Toko `/` dan halaman produk dibuka tanpa login. Pencarian meliputi nama, kategori, dan ciri tambahan; ejaan seperti Halfzip/Half Zip dan Quarterzip/Quarter Zip dinormalisasi, tetapi Quarter Zip tetap berbeda dari Half Zip. Kategori, ciri, fit, brand, rentang harga, dan pengurutan dapat dipakai bersama pada ukuran yang masih berstok. Harga dan fit harus cocok pada kelompok yang sama. Untuk produk dengan link Instagram, foto dan tombol **Lihat di Instagram** langsung membuka postingan asli; **Foto & detail di toko** membuka `/produk/<id>`. Produk mandiri tanpa Instagram tetap membuka halaman detail toko. Pembeli dapat melihat galeri, warna, kondisi, minus, deskripsi, ukuran aktual, dan stok tiap kelompok. Pilihan belanja tersimpan selama sesi saat berpindah antara koleksi dan detail, kemudian dibawa ke form pembayaran. Link Instagram di halaman detail bersifat opsional.

Filter berada di URL. Scroll disimpan hanya sebagai preferensi navigasi per sesi, bukan data produk. Katalog memperbarui stok setiap 15 detik saat aktif dan ketika kembali ke halaman; tersedia tombol **Perbarui stok**.

## Kategori utama dan ciri tambahan

Enam kategori utama: Polo, Kemeja, Sweater & Knitwear, Sweatshirt & Hoodie, Kaos, serta Jaket & Outerwear. Setiap barang memilih satu. Pada **Periksa/edit → Data barang**, centang beberapa ciri dalam kelompok Bukaan, Rajutan, Lengan, dan Model/kerah. Contoh Cable Knit Quarter Zip: kategori **Sweater & Knitwear**, ciri **Cable Knit** dan **Quarter Zip**. Nama asli barang tetap dipakai.

Pada tab **Kategori & ciri**, admin pemilik dan tim yang diotorisasi dapat menambah ciri standar serta variasi ejaan. Seluruh admin memakai daftar database yang sama; formulir barang tidak memakai isian ciri bebas. Istilah/alias yang dinormalisasi sama tidak boleh dipakai dua ciri, termasuk mencoba menyamakan Quarter Zip dengan Half Zip. Daftar yang terbuka diperbarui setiap 15 detik; **Muat terbaru** memperbarui segera. Tidak ada penghapusan ciri yang dapat memutus data barang lama.

Pembeli memilih kategori melalui tombol mendatar dan pilihan cepat Quarter Zip, Half Zip, Cable Knit, serta Polo Long Sleeve. Quarter Zip melintasi kategori. Beberapa kategori, size, atau brand berarti salah satu cocok; beberapa ciri di kelompok yang sama juga berarti salah satu cocok. Antar kelompok harus semuanya cocok. Cable Knit (Rajutan) + Quarter Zip (Bukaan) mensyaratkan keduanya. Polo Long Sleeve mensyaratkan kategori Polo dan ciri Long Sleeve. Size dan rentang harga tetap harus cocok pada kelompok stok yang sama; satu barang tetap satu kartu.

Migrasi menyimpan kategori asli pada `legacy_category`, memetakan hanya nama kategori umum yang jelas, dan mengisi ciri yang tertulis jelas di nama/kategori asli. Stok, fit, panjang/lebar, foto, harga, nama, status publikasi, dan riwayat tidak diubah. Versi produk dinaikkan agar editor lama tidak menimpa hasil migrasi. Label seperti Crewneck atau Quarter Zip tanpa jenis barang tidak dipaksakan menjadi kategori utama. Barang lama itu tetap tampil di **Semua** selama berstok dan diberi tanda **Kategori perlu diperiksa** di admin. Gunakan pilihan status tersebut untuk mengoreksinya. Barang baru harus memilih kategori utama sebelum diterbitkan; isian yang belum lengkap tetap berupa draf.

## Penyimpanan dan keamanan

Produk, kategori, daftar ciri/alias bersama, kelompok ukuran, dan riwayat berada di D1; foto di R2. Tidak ada stok utama di localStorage. Daftar koleksi hanya mengirim produk terbit dengan kelompok berstok positif. Endpoint detail hanya mengirim produk terbit, termasuk kelompok habis untuk menjelaskan ketersediaan. Permalink barang habis tetap dapat dibuka dengan pesan stok habis; barang itu hilang dari daftar koleksi. Caption sumber lama, tautan Instagram produk, dan riwayat tidak dikirim ke publik. Foto yang tidak terhubung ke produk terbit hanya dapat dibaca admin. Mencabut publikasi atau menghapus foto tambahan dari galeri mencabut akses publiknya, kecuali foto itu juga dipakai produk terbit lain.

Admin memakai Sign in with ChatGPT dan allowlist email di server. Semua operasi admin memeriksa izin backend. Permintaan tulis lintas origin ditolak. Stock menggunakan transaksi dan versi kelompok; editor menggunakan versi produk. Sesi/perangkat lama tidak boleh menimpa stok baru. Undo memakai riwayat/revisi yang tepat dan tidak boleh dilakukan dua kali.

Draf manual memakai identitas permintaan yang unik. Mencoba ulang setelah gangguan jaringan membuka draf yang sama, tanpa membuat kartu baru atau mengembalikan stok yang sudah terjual. Caption dan tautan postingan lama tetap tersimpan untuk riwayat; formulir manual tidak dapat mengubahnya. Perubahan ini tidak memerlukan migrasi atau reset data.

## Bantuan pembeli

Di kanan bawah koleksi dan halaman detail terdapat **Got question? ask us on dm or Whatsapp**. Ketuk untuk memilih **WhatsApp** (`https://wa.me/6285174389305`) atau **Instagram** (profil `@elite.vtg`, untuk mengirim DM). Parameter tracking pada tautan WhatsApp dibuang. Tautan membuka aplikasi/halaman terkait; tidak mengirim pesan otomatis. Pada HP tombol bantuan bergeser ke atas saat keranjang berisi barang. Panel dapat ditutup dengan mengetuk tombolnya, mengetuk di luar, atau Escape.

## Status input Instagram

Input caption, saran otomatis dari caption, field tautan Instagram produk, dan tab koneksi sudah dihapus dari alur admin. Operasi impor lama ditolak oleh backend (410), bukan sekadar disembunyikan di UI. Produk baru hanya dibuat sebagai formulir kosong dan diisi manual. Katalog, galeri, dan pembayaran tidak memerlukan token Instagram. Data sumber lama tidak dihapus. Endpoint status historis yang hanya dapat dibaca pemilik tetap terlindungi dan tidak mengirim token; tidak ada akses impor baru.

## Pengujian dan batas verifikasi

- `node tests/domain.mjs`: filter kategori/ciri/fit/harga, stok habis, dan utilitas parser historis (parser tidak digunakan untuk input baru).
- `node tests/product-card.mjs`: satu kartu/stok S/M, tautan produk native, dan nomor/tautan bantuan WhatsApp yang tepat.
- `node tests/integration.mjs`: Worker hasil build dengan database D1 dan penyimpanan R2 dalam lingkungan uji terisolasi, bukan mock database. Menguji izin, CSRF, penolakan impor caption/Instagram, formulir manual kosong, unggah foto, draf/publikasi, stok, dua sesi, konflik versi, duplikat, audit/undo, stok negatif, dan render server.
- `node node_modules/typescript/bin/tsc --noEmit`: pemeriksaan TypeScript.
- Bangun hasil terbaru dengan helper Sites `build-site.mjs` sebelum menjalankan integrasi.
- Data contoh dan foto uji tidak masuk produksi. Pengujian tidak mengubah stok atau produk yang sudah tersimpan di produksi.
- Browser interaktif dan HP/laptop fisik belum diuji dalam pembaruan ini. Uji dua sesi backend dan render server tidak sama dengan uji perangkat fisik.

## Konfigurasi proyek

Schema berada di `db/schema.ts`; schema diubah lewat Drizzle migrations, bukan saat runtime. `.openai/hosting.json` mempertahankan identitas proyek, `DB`, dan `BUCKET`. Source dan migrations disimpan melalui workflow penerbitan Sites.

`ADMIN_EMAIL` dan semua kredensial harus diatur di server, bukan `NEXT_PUBLIC_*`, source, atau manifest. `.env.example` berisi nama variabel saja; `.env` hanya untuk konfigurasi lokal dan tidak diterbitkan.

## Katalog → pembayaran → konfirmasi Telegram

Katalog dan pembayaran tetap dua aplikasi. Penghubung menggunakan secret server yang sama; sudah dikonfigurasi melalui pengaturan hosting. Token Instagram tidak diperlukan untuk penghubung pembayaran.

1. Di katalog publik, tekan **Pilih** pada kelompok ukuran yang dibeli. Tambah unit atau barang lain sesuai kebutuhan.
2. Tekan **Keranjang** di bawah layar atau **Buka keranjang** dari detail produk. Panel membuka pilihan langsung tanpa menggulir ke bawah koleksi. Periksa ukuran/jumlah, hapus barang yang tidak dipakai, lalu **Lanjut ke pembayaran**. **Lanjut belanja** menutup panel.
3. Nama, ukuran, jumlah, dan harga diisi dari database katalog. Pembeli melengkapi alamat dan ongkir, membayar QRIS, dan mengirim bukti seperti biasa.
4. Admin memeriksa dana masuk lalu mengonfirmasi invoice di Telegram. Stok berkurang sesuai kelompok dan jumlah, sekali per invoice.
5. Stok satu kelompok yang nol hilang dari pilihan/filter; kartu hilang jika semua kelompok habis. Riwayat menyebut nomor invoice.

Untuk pesanan dari chat Instagram, admin juga dapat memilih barang di katalog, membuka pembayaran, lalu menyalin alamat halaman pembayaran **sebelum mengisi data penerima** untuk dikirim kepada pembeli. Tautan membawa pilihan tersimpan selama 24 jam dan hanya bisa dipakai satu invoice. Jika diperlukan harga diskon, gunakan form pembayaran manual dan koreksi stok secara manual; harga pesanan katalog mengikuti katalog.

**Tautan pembayaran umum dan barang yang diketik manual tidak dipetakan otomatis ke katalog.** Invoice Telegram menandai apakah pesanan terhubung. Tidak ada tebakan barang dari namanya.

Stok tidak ditahan saat dipilih atau dibayar. Jika stok sudah tidak cukup ketika dikonfirmasi, pembayaran tetap tercatat, seluruh pemotongan stok untuk invoice tersebut ditolak, dan pengiriman ditahan. Admin perlu memeriksa stok fisik dan menangani pembeli. Jika hanya gangguan koneksi, tekan **Coba sinkron stok** di admin pembayaran atau **Coba ulang / cek resi & label** di Telegram. Percobaan ulang tidak menggandakan pemotongan.

Kesalahan jumlah bisa dikoreksi melalui admin katalog. **Batalkan perubahan terakhir** mengembalikan perubahan kelompok terakhir, tanpa mengubah status pembayaran atau membatalkan booking pengiriman. Untuk pesanan beberapa kelompok, periksa dan koreksi setiap kelompok yang perlu dipulihkan.

Konfigurasi server: katalog memakai `ORDER_ORIGIN` dan `CATALOG_BRIDGE_SECRET`; pembayaran memakai `CATALOG_ORIGIN` dan secret yang sama. Jangan menaruh secret dalam link, kode browser, atau chat. Pengiriman dan ongkir tetap memakai konfigurasi sebelumnya; keberhasilan potong stok tidak membuktikan provider pengiriman aktif.

Pengujian: 13 skenario gabungan menguji handler checkout, penyimpanan dua database, bukti, otorisasi callback Telegram, stok, retry, harga manipulasi, dan kompatibilitas pesanan manual. Telegram dan provider disimulasikan; tidak ada pembayaran, pesanan, atau stok contoh yang ditambahkan ke produksi. Pengujian Worker+D1 menguji pemotongan atomik dan callback serentak.

## Pembaruan toko mandiri

Migrasi menambah kolom deskripsi publik dan galeri foto tanpa menghapus barang, stok, caption sumber, foto utama, atau riwayat lama. Foto utama lama tetap menjadi galeri pertama. Caption sumber tetap khusus admin; deskripsi publik merupakan isian terpisah. Produk mandiri mempunyai identitas lokal yang unik. Pengulangan percobaan pembuatan draf dari formulir yang sama membuka draf tersimpan dan tidak menggandakan stok.

Pengujian baru memakai Worker hasil build, D1, dan R2 terisolasi: produk tanpa Instagram, galeri draf, pengulangan input, publikasi/deskripsi, permalink publik dan penolakan draf, penolakan foto tidak tersimpan, checkout lima unit tanpa Instagram, stok habis, pencabutan galeri, dan draf kosong yang wajib dilengkapi. Pengujian gabungan pembayaran/Telegram tetap lulus dengan layanan eksternal disimulasikan.

Galeri mendukung sampai 12 foto. Pembeli dapat memakai tombol sebelumnya/berikutnya dan ketuk foto untuk memperbesar di dalam toko. Tombol tutup atau Escape mengembalikan pembeli ke produk yang sama. Keranjang menampilkan foto kecil, ukuran, jumlah, subtotal barang, tombol hapus, dan sisa stok yang berubah. Ongkir tetap dihitung di form pesanan.


## Akses pemilik dan tiga anggota tim
Tombol Admin tidak ditampilkan pada katalog atau halaman produk publik. Pemilik membuka https://elite-vtg-katalog.farisfzi.chatgpt.site/admin dan login menggunakan akun ChatGPT pemilik yang sudah dikonfigurasi.

Pemilik tetap diperiksa dengan email terverifikasi dan identitas akun yang terikat di server. Dari tab **Akses tim**, tiga slot bernama Tim 1, Tim 2, dan Tim 3 disiapkan otomatis. Ubah nama menjadi nama anggota, klik Simpan nama, lalu Salin tautan dan kirim satu tautan secara pribadi untuk setiap anggota. Tautan bisa disalin kembali dari tab ini; server menyimpannya terenkripsi.

Anggota membuka tautan lengkap lalu menekan **Masuk ke katalog**. Tidak perlu menggunakan akun ChatGPT pemilik. Tautan dapat dipakai di HP dan laptop. Setelah masuk, anggota bisa menambah barang, mengunggah foto, menyusun draf, mengubah harga/stok, dan menerbitkan. Riwayat stok menandai nama akses yang dipakai.

Tautan adalah kunci akses: siapa pun yang menerima tautan tersebut memiliki izin katalog yang sama. Nama anggota hanya label akses, bukan verifikasi identitas orang. Jangan menaruh tautan di bio, katalog publik, atau pesan kepada pembeli. Alamat /admin atau /akses-tim saja tidak memberikan akses.

Hanya pemilik yang dapat membaca atau mengelola tiga tautan dan mengubah akses. Input impor Instagram telah dinonaktifkan. Dashboard pembayaran di https://elite-vtg-order.farisfzi.chatgpt.site/admin tetap khusus akun pemilik. Tautan tim tidak membuka QRIS, token Telegram, bukti pesanan, atau konfirmasi pembayaran.

**Cabut akses** membatalkan tautan dan semua sesi akses tersebut pada permintaan berikutnya, tanpa mematikan anggota lain. **Ganti tautan** juga membatalkan tautan/sesi lama dan menyediakan tautan baru. Kirim ulang tautan baru kepada anggota. Tautan berlaku 90 hari; sesi berlaku sampai 30 hari atau masa tautan berakhir. Anggota dapat membuka tautan yang masih aktif untuk masuk kembali. Tombol Keluar menghapus sesi di server.

Untuk menguji pengalaman tim atau pembeli, gunakan incognito/perangkat berbeda. Browser yang masih login sebagai pemilik akan tetap menampilkan izin pemilik. Jangan memberikan sesi pemilik Anda kepada anggota atau pembeli.
