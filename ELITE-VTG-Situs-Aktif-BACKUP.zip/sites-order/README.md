# ELITE.VTG Order

Private-first customer checkout and owner-only dashboard. Buyer enters agreed total including shipping. Payment uses the owner-uploaded static QRIS image; proof is always pending manual verification.

## Owner setup

Open `/admin`, sign in with the owning ChatGPT account, upload actual DANA QRIS, create a dedicated Telegram bot with BotFather, and paste its token into the owner dashboard. Open the generated private-chat pairing link, press Start, inspect the discovered identity, and explicitly confirm it. Send a test message. Bot tokens are AES-GCM encrypted in D1 under CONFIG_SECRET; no credential is returned to buyers.

OWNER_EMAIL is a platform-supplied bootstrap allowlist. First authorized owner sign-in pins the per-Site stable user ID in D1; all later admin requests use that ID. Admin remains protected if the customer page is later public. Do not remove/rotate CONFIG_SECRET without re-encrypting the saved Telegram credential. SITE_ORIGIN must match the hosted origin.

D1 stores orders/configuration, R2 privately stores QRIS/proof bytes. Buyer order access uses a random HttpOnly cookie and a SHA-256 session capability stored in D1; expires after seven days. Proof is downloadable only by the owner. Same-origin checks protect mutation endpoints, uploads are limited to JPG/PNG/WebP at 4 MB, and customer writes are rate-limited. No customer PII in local storage or public URLs.

Telegram invoices are plain text and proofs are uploaded as documents. Delivery records and a two-minute claim prevent concurrent resend; a partial failure resumes from the saved message ID. Rare timeout ambiguity cannot guarantee exactly-once delivery. Failed notifications remain available for owner retry. An owner may mark payment verified after checking actual funds in DANA.

Private deployment is deliberate. Public access requires the user's approval. Configure QRIS and test real Telegram delivery before sharing with buyers. The existing ongkir calculator is a separate private Site.

## Validation

Desktop and 390/320px mobile browser layouts checked. Full form → QRIS → proof → invoice flow passed using explicitly labeled local DATA UJI images and a local Telegram mock. Failure and partial notification retry preserved orders and resumed delivery; no live Telegram credentials or actual funds were used. Invoice persists on reload, copy matches the order, and server-based invoice download succeeds.

22 integration checks passed against the built Worker: owner/other/anonymous access, origin enforcement, input validation, session isolation, private proof access, file type/size rejection, and manual owner verification. TypeScript and targeted ESLint checks pass. Original auth and native Telegram implementation are restored; test fixtures and test data are excluded from the deployed artifact. Real Telegram delivery still needs owner pairing and the dashboard test message.
