# ELITE.VTG — Penghubung katalog dan pembayaran

Katalog: https://elite-vtg-katalog.farisfzi.chatgpt.site
Pembayaran: https://elite-vtg-order.farisfzi.chatgpt.site

Pilih barang dan kelompok ukuran di katalog → Lanjut ke pembayaran → isi penerima/ongkir → bayar dan unggah bukti → admin memastikan dana masuk dan mengonfirmasi invoice Telegram → stok berkurang sekali.

Stok otomatis hanya untuk pesanan yang berasal dari tautan pilihan katalog. Pesanan manual tetap berfungsi dan invoice menyatakan bahwa stok tidak terhubung. Untuk pesanan chat, admin bisa membuat tautan dengan memilih barang di katalog dan menyalin URL halaman pembayaran sebelum mengisi penerima. Tidak diperlukan setup bot baru.

Tab admin pembayaran menampilkan status penghubung dan status stok per invoice. Bila gangguan koneksi terjadi, gunakan Coba sinkron stok atau tombol Coba ulang Telegram. Bila stok tidak cukup, periksa stok fisik dan pesanan pembeli; tidak ada pemotongan sebagian atau stok negatif, dan pengiriman ditahan. Aplikasi tidak menahan stok sebelum konfirmasi sehingga dua pembeli dapat membayar barang terakhir yang sama.

Pembayaran terkonfirmasi tetap tercatat ketika sinkron stok gagal. Ledger unik di katalog mencegah pemotongan ganda, termasuk bila respons jaringan hilang sesudah commit. Pembayaran manual, proses ongkir, tiga pesan awal Telegram, dan pengecekan pemilik tetap dipertahankan.

Konfigurasi hosting server: CATALOG_ORIGIN dan CATALOG_BRIDGE_SECRET. Secret harus sama dengan katalog dan disimpan sebagai secret server. Konfigurasi tersebut sudah dipasang untuk dua aplikasi ELITE.

Untuk menjalankan pengujian gabungan, buka kedua checkout pada folder saudara elite-vtg-order dan elite-vtg-katalog, lalu jalankan node --test tests/catalog-integration.test.mjs dari aplikasi pembayaran. Seluruh koneksi eksternal disimulasikan dan semua database uji bersifat sementara.
